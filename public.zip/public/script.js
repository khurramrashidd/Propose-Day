// ================== AWS CONFIG ==================
const REGION = "eu-north-1";
const IDENTITY_POOL_ID = "eu-north-1:cf2cfbd3-fcfe-4df2-af8d-a028afd3b20e";
const TABLE_NAME = "Proposals";

AWS.config.update({
  region: REGION,
  credentials: new AWS.CognitoIdentityCredentials({
    IdentityPoolId: IDENTITY_POOL_ID
  })
});

const ddb = new AWS.DynamoDB.DocumentClient();
// ===============================================

let proposals = [];
let currentDownloadProposal = null;

// Create floating hearts
function createFloatingHearts() {
  const bg = document.getElementById('hearts-bg');
  bg.innerHTML = '';
  for (let i = 0; i < 28; i++) {
    const heart = document.createElement('div');
    heart.className = 'heart';
    heart.textContent = ['❤️','💖','💗','💘','💝'][Math.floor(Math.random()*5)];
    heart.style.left = Math.random() * 100 + 'vw';
    heart.style.animationDuration = (Math.random() * 18 + 15) + 's';
    heart.style.animationDelay = '-' + Math.random() * 20 + 's';
    heart.style.fontSize = (Math.random() * 22 + 20) + 'px';
    bg.appendChild(heart);
  }
}

// Dark Mode
function toggleDarkMode() {
  document.documentElement.classList.toggle('dark');
  localStorage.setItem('darkMode', document.documentElement.classList.contains('dark'));
}

// Sidebar
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('-translate-x-full');
}

// Add Proposal
async function addProposal() {
  const style = document.getElementById('style').value;
  const message = document.getElementById('message').value.trim();
  const name = document.getElementById('name').value.trim() || 'Anonymous';

  if (!message) return alert('Please write your proposal 💌');

  const params = {
    TableName: TABLE_NAME,
    Item: {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      style: style,
      message: message,
      name: name,
      timestamp: Date.now(),
      likes: 0
    }
  };

  try {
    await ddb.put(params).promise();
    confetti({ particleCount: 160, spread: 90, origin: { y: 0.6 } });
    document.getElementById('message').value = '';
    document.getElementById('name').value = '';
    loadProposals();
  } catch (err) {
    console.error(err);
    alert('Error sending proposal');
  }
}

// Like Proposal
async function likeProposal(id) {
  try {
    await ddb.update({
      TableName: TABLE_NAME,
      Key: { id: id },
      UpdateExpression: "ADD likes :inc",
      ExpressionAttributeValues: { ":inc": 1 }
    }).promise();
    loadProposals();
  } catch (err) { console.error(err); }
}

// Share
function shareProposal(message) {
  navigator.clipboard.writeText(`"${message}"\n\n— Shared from ProposeHub 💍`);
  alert("Proposal copied to clipboard! ❤️");
}

// Download Card Modal
function showDownloadModal(message, name) {
  currentDownloadProposal = { message, name };
  document.getElementById('download-modal').classList.remove('hidden');
  document.getElementById('from-name').focus();
}

function closeModal() {
  document.getElementById('download-modal').classList.add('hidden');
}

async function generateAndDownloadCard() {
  const from = document.getElementById('from-name').value.trim() || "Someone Special";
  const to = document.getElementById('to-name').value.trim() || "My Love";

  const cardHTML = `
    <div class="download-card">
      <div class="download-card-content">
        <h1>To</h1>
        <p class="to">${to}</p>
        <p class="message">"${currentDownloadProposal.message}"</p>
        <p class="from">From: ${from}</p>
        <div style="margin-top:40px; font-size:13px; color:#831843;">ProposeHub • 2026</div>
      </div>
    </div>
  `;

  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = cardHTML;
  document.body.appendChild(tempDiv);

  try {
    const canvas = await html2canvas(tempDiv.firstElementChild, { scale: 3 });
    const link = document.createElement('a');
    link.download = `Proposal_for_${to}.jpg`;
    link.href = canvas.toDataURL('image/jpeg', 0.95);
    link.click();
  } catch (e) {
    alert("Download failed. Try again.");
  }

  document.body.removeChild(tempDiv);
  closeModal();
}

// Trending Dummy Data
const trendingDummy = [
  { id: "t1", style: "romantic", message: "Every love story is beautiful, but ours is my favorite.", name: "Aarav", likes: 124 },
  { id: "t2", style: "poetic", message: "You are the poem I never knew I wanted to write.", name: "Vihaan", likes: 98 },
  { id: "t3", style: "cute", message: "Can I borrow a kiss? I promise I'll give it back.", name: "Ishaan", likes: 87 },
  { id: "t4", style: "bold", message: "I'm not proposing... I'm just asking you to be mine forever.", name: "Reyansh", likes: 76 },
  { id: "t5", style: "romantic", message: "You + Me = Forever. Deal?", name: "Kabir", likes: 65 }
];

function showTrending() {
  renderProposals(trendingDummy);
}

// Render Proposals
function renderProposals(data) {
  const wall = document.getElementById('wall');
  wall.innerHTML = '';

  data.forEach(item => {
    const div = document.createElement('div');
    div.className = `proposal ${item.style} p-6`;
    div.innerHTML = `
      <div class="flex justify-between items-start">
        <span class="text-4xl">${item.style === 'romantic' ? '❤️' : item.style === 'cute' ? '🥰' : item.style === 'funny' ? '😂' : item.style === 'bold' ? '🔥' : '✨'}</span>
        <button onclick="likeProposal('${item.id}')" class="like-btn text-2xl hover:scale-125">❤️ <span>${item.likes || 0}</span></button>
      </div>
      <p class="msg text-lg leading-relaxed my-5">"${item.message}"</p>
      <div class="flex justify-between items-center text-sm">
        <small class="text-gray-600">~ ${item.name}</small>
        <div class="flex gap-3">
          <button onclick="shareProposal('${item.message.replace(/'/g, "\\'")}')" class="text-rose-500 hover:text-rose-600">
            <i class="fas fa-share"></i>
          </button>
          <button onclick="showDownloadModal('${item.message.replace(/'/g, "\\'")}', '${item.name}')" 
                  class="text-rose-600 font-medium hover:underline">Download Card ↓</button>
        </div>
      </div>
    `;
    wall.appendChild(div);
  });
}

// Filter
function filterProposals() {
  const term = document.getElementById('search').value.toLowerCase();
  const filtered = proposals.filter(p => 
    p.message.toLowerCase().includes(term) || p.name.toLowerCase().includes(term)
  );
  renderProposals(filtered);
}

// Load Real Proposals
async function loadProposals() {
  try {
    const data = await ddb.scan({ TableName: TABLE_NAME, Limit: 200 }).promise();
    proposals = data.Items.sort((a, b) => b.timestamp - a.timestamp);
    renderProposals(proposals);
  } catch (err) {
    console.error(err);
  }
}

// Init
function init() {
  createFloatingHearts();
  loadProposals();

  if (localStorage.getItem('darkMode') === 'true') {
    document.documentElement.classList.add('dark');
  }

  document.getElementById('sidebar-btn').addEventListener('click', toggleSidebar);
}

window.onload = init;